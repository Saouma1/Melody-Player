package melodymaker;
// TODO: Write the code for this class.

import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Melody {

    Deque<Note> queue = new LinkedList();
    Stack <Note> stack = new Stack();

    public Melody(Deque<Note> song) {
        queue = new LinkedList();
        Note note;
        
        while (!song.isEmpty()){
            note = song.poll();
            
            queue.add(note);
            
        }

    }

    public double getTotalDuration() {
        double totalLength = 0;
        for (int i = 0; i < queue.size(); i++) {
            Note note = queue.remove();
            totalLength = note.getDuration() + totalLength;
            queue.add(note);
        }
        return totalLength;
    }

    public void changeTempo(double tempo) {
        for (int i = 0; i < queue.size(); i++) {
            Note note = queue.remove();
            double duration = note.getDuration() * tempo;
            note.setDuration(duration);
        }

    }

    public void reverse() {
       while(!queue.isEmpty()) {  
            stack.add(queue.remove()); 
        }
       while(!stack.isEmpty()){
           queue.add(stack.pop());
       }
    }

    public void append(Melody other) {
        for( int i =0; i<=other.queue.size();i++){
            Note Notes = other.queue.poll();
            queue.add(Notes);
            other.queue.add(Notes);
        }
        

    }

    public void play() {

        if (!queue.isEmpty()) 
            for (int i = 0; i < queue.size(); i++) {
                Note note = queue.remove();
                note.play();
                queue.add(note);
            }
        
    }

    public String tostring() {
        String q = "";
        Note note;
        for (int i = 0; i < queue.size(); i++) {
            note = queue.poll();

            q += note + "\n";

            queue.add(note);
        }
        return q;
    }

}






